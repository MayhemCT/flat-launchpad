# CallZ smart contracts: review package v7

Source: https://github.com/MayhemCT/flat-launchpad, commit `5709d72` (27 Nov 2026).
Solidity 0.8.26, EVM version cancun, optimizer on (see "Build settings").

v7 is v6 with no source change: every contract, script and test is byte-for-byte the v6 file, which is the
repository at `5709d72`. What is new is that this code is now deployed on BNB Chain, and this file says so (see
"Deployed"). v6 is v5 with one contract changed: `CallZVault.sol`, and its test file. Every other source, script
and test is byte-for-byte the v5 file, and `foundry.toml` is unchanged.

**`CallZLauncher` 1.1.0 and `CallZLauncherFactory` are not touched.** They are the code the full pre-audit
passed on 27 Nov 2026 (0 critical, 0 high, 3 disclosure notes). The factory's creation code in
`deployment/CallZLauncherFactory.create2.json` is identical to v5's, and its address is still
`0x1C43a0bBf01034c30c9d30F23C00E7F3019E678c`.

## What changed since v5: CallZVault.sol

v6 answers the three vault items left after the v4 review.

### 1. `setTeamWallet` and `setRules` changed at once

Both are gone. The guardian now schedules either change, in public, and it takes effect two days later, the
same way the attester and the split already did:

- `scheduleTeamWallet(address)`, `cancelTeamWallet()`, `applyTeamWallet()`; pending values `pendingTeamWallet`,
  `teamWalletEta`; event `TeamWalletScheduled`.
- `scheduleRules(requiredLinks, maxLinksPerEpoch, minHoldPpm)`, `cancelRules()`, `applyRules()`; pending values
  `pendingRequiredLinks`, `pendingMaxLinksPerEpoch`, `pendingMinHoldPpm`, `rulesEta`; event `RulesScheduled`.

The wait is `CHANGE_DELAY` (2 days). Until it is over the wallet and rules in place keep applying. Anyone can
call the `apply…` function afterwards. Scheduling again replaces the pending value and restarts the wait.

After this, the only thing the guardian can do in the vault at once is `setSubmissionsPaused`, which can stop
callouts being recorded and cannot move money. `transferGuardian` is still a two-step handover with no delay.

### 2. One bag moved between wallets diluted the other callers

In v5 a bag passed between two callers' wallets was paid once (the checkpoint), but both snapshots stayed in the
round's total weight, so the other callers of the round earned less, and the part allotted to the empty wallet
was swept to the team wallet.

v6 works the holder share out at the checkpoint instead of as fees arrive:

- A deposit only adds to the round's holder share (`pot`). `Round.acc` and `Entry.accAtJoin` are gone. Each
  caller records the size of the holder share when they joined (`Entry.potAtJoin`).
- `checkpoint` (taken by the round's first claim, or by anyone, after the round ends) reads every caller's
  balance in one transaction, as before. Each caller's weight is their snapshot weight cut down to the part of
  the snapshot they still hold. The fees that arrived between one caller joining and the next are shared
  between the callers already in the round, by those weights (`_shares`). The result is stored per caller
  (`Entry.share`) and is what `claim` pays.
- So a snapshot of tokens that have left the wallet weighs nothing: it takes nothing from the other callers,
  and nothing of it goes to the team. The other callers are paid what they would have been paid had that
  snapshot never been taken. `test_20` shows it with three callers.
- The same holds for a caller who sold: what they give up goes to the callers who still hold. A stretch of
  fees whose callers all hold nothing at the checkpoint is owed to nobody and is swept with the round
  (`test_21`). Rewards not claimed within 24 hours still go to the team wallet, as before.
- The shares of a round add up to no more than its holder share (each is rounded down), and every payout still
  goes through the per-token ledger (`_book`), which reverts with `Insolvent()` past what the token's fees
  brought in.
- `progress()` shows, for a finished round that has no checkpoint yet, what a checkpoint taken now would fix
  for that wallet, from the balances of all the round's callers as they are now. After the checkpoint it shows
  the fixed amount.
- The 256-holder cap per round and token is unchanged. A full round's checkpoint is under 8M gas (`test_19`).

Unchanged in shape: `deposit`, `submitAttested`, `claim`, `claimMany`, `checkpoint`, `collect`, `roundOf`,
`progress`, `ledgerOf`, `callersOf`, and the `Submission` struct, so the EIP-712 type the attester signs is
the same.

### 3. Weights depend on what the attester signs

This cannot be removed on-chain, and v6 does not claim to. The market cap at the time of a post is not
something a contract can read back. What bounds it:

- The attester can be a separate key from the guardian and the team wallet, or a multisig: the vault checks a
  plain signature first and then ERC-1271 (`_signedByAttester`).
- A new attester waits two days (`scheduleAttester`), and the guardian can stop every new callout at once
  (`setSubmissionsPaused`).
- A snapshot is never more than the wallet holds on-chain when the callout is recorded, a holder needs 0.01%
  of the supply, records at most 3 links a round, and a round's holder share takes 256 holders.
- Whatever is signed, a token can never pay out more than its own fees brought in.

At deployment the first attester is the team wallet (a constructor argument, so it is part of the CREATE2
address). To separate the keys without moving the address, the guardian schedules the new attester after
deployment and it takes over two days later.

## Still true, and disclosed

- **Holdings are read at one moment.** The vault locks nothing. A caller who sold can hold the tokens again
  for the moment of the checkpoint, at the cost of buying them back (two swaps and the token's own taxes), and
  is then paid as if they had held. Only locking tokens would rule this out, and this design does not lock.
- **The attester is trusted** for the market cap and holdings at the time of a post (above).
- **Curve path** (`CallZCurve.sol`, not deployed): as in v5. The dividend contract's source was not read; its
  behaviour is from what the fork showed.
- **The floor check** in `CallZLauncher` uses the Portal's price and the factory's multiplier at the moment a
  mint is created (pre-audit note Y1 and v5).
- **The site's own fork test of the fee flow** (`apps/web/tests/fees.pw.ts`) was not re-run on v6. The vault
  functions the site and its Worker call are unchanged.

## Tests run on this code, 27 Nov 2026

| Suite | Chain | Result |
| --- | --- | --- |
| `CallZLauncher.BSCTest.fork.t.sol` | live Pool Launch Portal on BNB Chain Testnet | 18 of 18 pass |
| `CallZLauncher.BSC.fork.t.sol` | a fork of BNB Chain | 18 of 18 pass |
| `CallZFees.BSC.fork.t.sol` (vault, router, launch fee) | a fork of BNB Chain | 22 of 22 pass |
| `CallZPancake.BSC.fork.t.sol` | a fork of BNB Chain | 16 of 16 pass |
| `CallZCurve.BSC.fork.t.sol` | a fork of BNB Chain | 10 of 10 pass |

84 of 84 in one run of the whole suite (`forge test --isolate`).

Vault tests added in v6: `test_20_aBagPassedBetweenWalletsTakesNothingFromTheOtherCallers`,
`test_21_aFeeWhoseCallersHoldNothingStaysInTheRound`, `test_22_theTeamWalletAndTheRoundRulesWaitOutTheDelay`.
Changed to match the new rules: `test_07` (team wallet and rules through the delay), `test_11` and `test_17`
(the caller who holds is paid the whole holder share), `test_14` (a caller who sold half weighs half).

## What to review

Our own contracts are the nine files in `src/callz/`:

| File | What it is |
| --- | --- |
| `CallZLauncher.sol` | The NFT pass mint built on Flap's `LauncherBase`, for Flap Pool Launch. Unchanged since v3. |
| `CallZLauncherFactory.sol` | A Flap Launcher Factory that creates `CallZLauncher` mints. Unchanged. |
| `CallZVault.sol` | Holds every fee and pays callout rewards. No staking. **Changed in this package.** |
| `CallZRouter.sol` | Swaps through PancakeSwap V2 and takes the trading fee on the BNB side. Unchanged. |
| `CallZPancake.sol` | The same mint launching a token straight into a PancakeSwap V2 pool. Unchanged. |
| `CallZPancakeFactory.sol` | Creates `CallZPancake` mints. Unchanged. |
| `CallZToken.sol` | The plain ERC-20 a `CallZPancake` mint launches: fixed supply, no owner, no tax. Unchanged. |
| `CallZCurve.sol` | The same mint launching through Flap's bonding curve. Unchanged since v5. |
| `CallZCurveFactory.sol` | Creates `CallZCurve` mints. Unchanged. |

`src/flap/` holds Flap's own base contracts and interfaces that `CallZLauncher` builds on. They are Flap's
code, included so the package compiles.

## Deployed (read from the chain on 27 Nov 2026)

```
BNB Chain Testnet
CallZLauncherFactory     0x1C43a0bBf01034c30c9d30F23C00E7F3019E678c   this package's code: DEPLOYED, no Launcher created yet
CallZLauncher impl.      0x42f004f13E26Ef588B8a9CA95c46057eC4870c37   created by that factory's constructor; version() 1.1.0
CallZLauncherFactory     0x873040D38Bd73eF1cE7d8D814278605CF6b697b3   the v2 code, without the scam-word check; one live launch
CallZLauncherFactory     0x2D085c23BBB95e8f0C34b046573BDc88fAd538F0   the code before v2; unused

BNB Chain (mainnet): this package's code, DEPLOYED 27 Nov 2026
CallZLauncherFactory     0x1C43a0bBf01034c30c9d30F23C00E7F3019E678c   same creation code, so the same address as on testnet; not enabled by Flap yet
CallZLauncher impl.      0x42f004f13E26Ef588B8a9CA95c46057eC4870c37   created by that factory's constructor; version() 1.1.0
CallZVault               0x78578cB78c57354E4ecaAF8033646aabC49b8902
CallZRouter              0x09BF2F6c6988C12b82BeBA3936e7b3A602a1dc57   (same source as v2; a new address because it names the vault)
CallZPancakeFactory      0xfFe694AC904B2FC664cd8f0D83AEA156EeBB321f   (same source as v2; a new address because it names the vault)

BNB Chain (mainnet): earlier deployments, the v2 code, no longer used
CallZVault               0x68459955E16EDd44319218101f60aD2b379401b6   (never received a fee)
CallZRouter              0x1439694F14999D5999b1735bC67e70260CAce10C
CallZPancakeFactory      0x28507071955b19E99C5DDa572fc690b8856f65D0   (created no mint)
CallZPancakeFactory v1   0xf4Ce206dFEDFadc826DC355097648Fd3Df9a4fB3   (no fee; its mints still list)
```

The v5 addresses of the vault, router and mint factory (`0x15Bb…230A`, `0xC9Ff…3e07`, `0xe8D8…43ba`) were
never deployed and are superseded by the three above.

The four mainnet addresses are the CREATE2 addresses of the creation code in `deployment/` (the deterministic
deployer `0x4e59b44847b379578588920cA78FbF26c0B4956C`, the salts and constructor arguments in those files). All
four were deployed from the site on 27 Nov 2026 by the team wallet `0x2FcB91295c790d15d5f21eD9D95C6a89E0683C58`.
Read from BNB Chain afterwards:

- The code at each address equals the runtime code `forge build` produces from this package, once immutables
  are set aside: Launcher Factory 6,345 bytes, Launcher implementation 22,215 bytes, vault 22,379 bytes, router
  4,963 bytes, mint factory 3,271 bytes.
- Launcher Factory: `hub()` is the Pool Launch Portal `0x000042108465206185A077Edc3F3fd2b49060000`,
  `guardian()` is Flap's mainnet Guardian `0x9e27098dcD8844bcc6287a557E0b4D09C86B8a4b`, and it has created no
  Launcher. On BNB Chain the Portal accepts its Launchers only once Flap has enabled the factory
  (`setLauncherFactoryMultiplier`).
- Vault: guardian, attester and team wallet are the team wallet; the split is 4500 / 3000 / 2500 bps;
  `CHANGE_DELAY` is 2 days; `MAX_ROUND_CALLERS` is 256; submissions are not paused; it has received no fee and
  has no round.
- Router: `vault()` is that vault; the trading fee is 200 bps. Mint factory: `vault()` is that vault; the launch
  fee is 1000 bps; it has created no mint.

The site's launch flow and its fee flow (a buy and a sell paying the vault and the team wallet, and a callout
going from posted to approved, recorded and claimed) were run through the pages on a fork of BNB Chain against
these deployed contracts on 27 Nov 2026: 4 of 4 pass.

The v2 factory, `0x8730…97b3`, has one live launch on BNB Chain Testnet, made from the site on 27 Nov 2026:
Launcher `0x86A22874083777D066359D6ef3661C6D8f186E90` sold 16 passes at 0.1 tBNB, reached its 1.6 tBNB cap and
launched the token CZTEST `0xF53F1C30ac65095f04845F10E1E1935702387777` in the same transaction
(`0xf61c38701bd424d60b316d0578b3fd2f778372385b9e95b6a5c529fd29fc26fa`). That launch ran the v2 code, not the
code in this package. The launch passes no vault factory: the token's tax is split between dividends,
liquidity and burn.

`CallZCurveFactory` is not deployed. Every address is a CREATE2 address that depends only on the bytecode, so
a change to a source moves its address.

## Build settings

`foundry.toml`: Solidity 0.8.26, EVM version cancun, optimizer on. 99,999 runs for every contract except
`src/callz/CallZLauncher.sol` and what is compiled with it, which use 2,000 runs (a second compiler profile and
a compilation restriction on that file). Build from a clean `out/`: artifacts left from a build with other
settings are not overwritten in place. `CallZVault` is 22,379 bytes of runtime code, 2,197 under the limit.

The sources are checked out with LF line endings. The compiler's metadata hash covers the source bytes, so a
checkout with CRLF line endings gives different bytecode and different CREATE2 addresses.

## Dependencies (not in this package)

- Solady 0.1.26: `ERC721`, `SafeTransferLib`, `LibClone`, `LibString`, `Base64`, `ReentrancyGuard`,
  `UpgradeableBeacon`, `SignatureCheckerLib`, `FixedPointMathLib`, `EIP712`, `ECDSA`
- OpenZeppelin Contracts 4.9.6: `ERC20`
- OpenZeppelin Contracts Upgradeable 4.9.6: `Initializable`
- forge-std 1.8.2 (tests only)

## Build and test

```
forge install vectorized/solady@v0.1.26 OpenZeppelin/openzeppelin-contracts@v4.9.6 OpenZeppelin/openzeppelin-contracts-upgradeable@v4.9.6 foundry-rs/forge-std@v1.8.2
forge build
BSC_TESTNET_RPC_URL=<a BNB Chain Testnet endpoint> BSC_RPC_URL=<a BNB Chain endpoint> forge test --isolate
```

`forge install` needs a git repository: run `git init` in the package folder first.

The tests in `test/callz/` are fork tests: they run against the live PancakeSwap, Flap Portal, Flap anti-scam
module and Flap tokens on a fork of BNB Chain, and against the live Pool Launch Portal on BNB Chain Testnet for
`CallZLauncher`, so they need RPC endpoints.

`README.md` in this package is the project's own, with the design of each launch path and the fee and reward
rules in full ("Fees and the vault").
