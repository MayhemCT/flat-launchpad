// Checks the CallZ launch on BNB Chain Testnet against the chain itself.
//
//   node check.mjs                      uses a public BNB Chain Testnet endpoint
//   node check.mjs <rpc url>            uses the endpoint you give it
//
// Needs Node 18 or newer and nothing else. It only reads: it sends no transaction and needs no wallet.
// Every line it prints is a fact read from the chain and compared with what the report says. It exits with
// code 1 if any check fails.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const RPC = process.argv[2] ?? process.env.BSC_TESTNET_RPC_URL ?? "https://bsc-testnet-rpc.publicnode.com";

// ── What the report says ─────────────────────────────────────────────────────────────────────────────────
const CHAIN_ID = 97n;
const FACTORY = "0x873040d38bd73ef1ce7d8d814278605cf6b697b3";
const BEACON = "0x22e07928abd89b20d560b6dfcb0e1e5d72c2ab0a";
const IMPLEMENTATION = "0xd9d4a8fc93156fed60de5960a2a25b15591bf651";
const LAUNCHER = "0x86a22874083777d066359d6ef3661c6d8f186e90";
const TOKEN = "0xf53f1c30ac65095f04845f10e1e1935702387777";
const POOL = "0xb9e05d4a0b7dc8fb98bdcc12ced52d107ef6ac2d";
const WBNB = "0xae13d989dac2f0debff460ac112a837c89baa7cd";
const PORTAL = "0x000042108465206185a077edc3f3fd2b49060000";
const CREATOR = "0x2fcb91295c790d15d5f21ed9d95c6a89e0683c58";
const DEAD = "0x000000000000000000000000000000000000dead";
const ZERO = "0x0000000000000000000000000000000000000000";

const CREATE_TX = "0x598a2d9549deb0ae6ff3ef2212df7fe7958199c1eccb51419d40086ccd20204a";
const LAUNCH_TX = "0xf61c38701bd424d60b316d0578b3fd2f778372385b9e95b6a5c529fd29fc26fa";
const CLAIM_TX = "0x981e085b8addf6f9bf2b381e9f112bec5772c3b148bcfc7ebc739683b212ec8e";

const ETHER = 10n ** 18n;
const PRICE = ETHER / 10n; // 0.1 tBNB a pass
const CAP = (16n * ETHER) / 10n; // 1.6 tBNB
const PASSES = 16n;
const SUPPLY = 1_000_000_000n * ETHER;
const POOL_TOKENS = 750_000_000n * ETHER; // 75% of the supply
const HOLDER_TOKENS = 250_000_000n * ETHER; // the rest, shared by the passes
const TOKENS_PER_PASS = 15_625_000n * ETHER;
const LP_BURNED_AT_LAUNCH = 34641016151377545869548n;

// keccak-256 of the code at each address, as read on 27 Nov 2026. The implementation's is also the hash of
// the runtime code `forge build` produces from src/callz/CallZLauncher.sol in this package.
const FACTORY_CODE_HASH = "0x2c17e4e4ce667413360c23ea4124736091f661e55be3b27c66ddd9a06801ac0e";
const IMPLEMENTATION_CODE_HASH = "0xd9baec2fdc28958e0f7156d2b717144c737bacc885b0780bfb4bc7c59f2e62f2";

// ── keccak-256 ───────────────────────────────────────────────────────────────────────────────────────────
const MASK = (1n << 64n) - 1n;
const ROUND = [
  0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n, 0x000000000000808bn, 0x0000000080000001n,
  0x8000000080008081n, 0x8000000000008009n, 0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
  0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n, 0x8000000000008002n, 0x8000000000000080n,
  0x000000000000800an, 0x800000008000000an, 0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n,
];
const ROTATION = [0, 1, 62, 28, 27, 36, 44, 6, 55, 20, 3, 10, 43, 25, 39, 41, 45, 15, 21, 8, 18, 2, 61, 56, 14];
const rotl = (value, by) => (by === 0 ? value : ((value << BigInt(by)) | (value >> BigInt(64 - by))) & MASK);

function permute(state) {
  for (let round = 0; round < 24; round++) {
    const column = [0, 1, 2, 3, 4].map((x) => state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20]);
    for (let x = 0; x < 5; x++) {
      const mix = column[(x + 4) % 5] ^ rotl(column[(x + 1) % 5], 1);
      for (let y = 0; y < 25; y += 5) state[x + y] ^= mix;
    }
    const moved = new Array(25);
    for (let x = 0; x < 5; x++) {
      for (let y = 0; y < 5; y++) moved[y + 5 * ((2 * x + 3 * y) % 5)] = rotl(state[x + 5 * y], ROTATION[x + 5 * y]);
    }
    for (let y = 0; y < 25; y += 5) {
      for (let x = 0; x < 5; x++) state[x + y] = moved[x + y] ^ (~moved[((x + 1) % 5) + y] & MASK & moved[((x + 2) % 5) + y]);
    }
    state[0] ^= ROUND[round];
  }
}

/** keccak-256 of bytes, as a 0x hex string. */
function keccak(bytes) {
  const rate = 136;
  const padded = new Uint8Array(Math.ceil((bytes.length + 1) / rate) * rate);
  padded.set(bytes);
  padded[bytes.length] ^= 0x01;
  padded[padded.length - 1] ^= 0x80;
  const state = new Array(25).fill(0n);
  const view = new DataView(padded.buffer);
  for (let offset = 0; offset < padded.length; offset += rate) {
    for (let lane = 0; lane < rate / 8; lane++) state[lane] ^= view.getBigUint64(offset + lane * 8, true);
    permute(state);
  }
  const out = new DataView(new ArrayBuffer(32));
  for (let lane = 0; lane < 4; lane++) out.setBigUint64(lane * 8, state[lane], true);
  return toHex(new Uint8Array(out.buffer));
}

const toHex = (bytes) => "0x" + [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
const fromHex = (hex) => Uint8Array.from((hex.slice(2).match(/../g) ?? []).map((pair) => parseInt(pair, 16)));
const text = (value) => new TextEncoder().encode(value);
const topicOf = (signature) => keccak(text(signature));
const word = (value) => (typeof value === "bigint" ? value.toString(16) : value.slice(2)).padStart(64, "0");
const addressOf = (wordHex) => "0x" + wordHex.slice(-40).toLowerCase();

// ── The chain ────────────────────────────────────────────────────────────────────────────────────────────
/** The endpoint answered, and the answer was an error: for a read, the contract refused the call. */
class Refused extends Error {}

let requestId = 0;
async function rpc(method, params, endpoint = RPC) {
  for (let attempt = 1; ; attempt++) {
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: ++requestId, method, params }),
      });
      const body = await response.json();
      if (body.error) throw new Refused(`${method}: ${body.error.message}`);
      return body.result;
    } catch (cause) {
      // A refusal is an answer; only a failure to reach the endpoint is worth trying again.
      if (cause instanceof Refused || attempt === 3) throw cause;
      await new Promise((resolve) => setTimeout(resolve, 700 * attempt));
    }
  }
}

/**
 * A read-only call. `signature` is the function, e.g. "balanceOf(address)"; `args` are addresses or numbers.
 * A call the contract refuses, or one to an address with no contract, reads as nothing: the check that asked
 * for it then fails with what was found, and the rest still run.
 */
async function read(to, signature, args = []) {
  const data = topicOf(signature).slice(0, 10) + args.map(word).join("");
  try {
    return (await rpc("eth_call", [{ to, data }, "latest"])).slice(2);
  } catch (cause) {
    if (cause instanceof Refused) return "";
    throw cause;
  }
}
const readNumber = async (to, signature, args) => BigInt("0x" + ((await read(to, signature, args)) || "0"));
const readAddress = async (to, signature, args) => {
  const result = await read(to, signature, args);
  return result.length >= 40 ? addressOf(result) : "nothing";
};
const readBool = async (to, signature, args) => (await readNumber(to, signature, args)) === 1n;
async function readString(to, signature) {
  const bytes = fromHex("0x" + (await read(to, signature)));
  if (bytes.length < 64) return "nothing";
  const length = Number(BigInt(toHex(bytes.slice(32, 64))));
  return new TextDecoder().decode(bytes.slice(64, 64 + length));
}
const codeHash = async (address) => keccak(fromHex(await rpc("eth_getCode", [address, "latest"])));

// Some public endpoints stop serving a transaction's record once it is a few days old. These are BNB Chain's
// own testnet endpoints and one more public one, asked only when the endpoint in use refuses.
const OTHER_ENDPOINTS = [
  "https://data-seed-prebsc-1-s1.bnbchain.org:8545",
  "https://data-seed-prebsc-2-s1.bnbchain.org:8545",
  "https://bsc-testnet.drpc.org",
];

/**
 * A transaction's record: its outcome and the events it emitted. `null` when the chain has no such
 * transaction, `undefined` when no endpoint would serve it.
 */
async function receipt(hash) {
  try {
    return await rpc("eth_getTransactionReceipt", [hash]);
  } catch (cause) {
    if (!(cause instanceof Refused)) throw cause;
    console.log(`  NOTE  ${RPC} would not serve transaction ${hash.slice(0, 10)}… (${cause.message})`);
  }
  for (const endpoint of OTHER_ENDPOINTS) {
    try {
      if (BigInt(await rpc("eth_chainId", [], endpoint)) !== CHAIN_ID) continue;
      const found = await rpc("eth_getTransactionReceipt", [hash], endpoint);
      console.log(`  NOTE  read it from ${endpoint} instead`);
      return found;
    } catch {
      // The next endpoint is asked.
    }
  }
  return undefined;
}

// ── Reporting ────────────────────────────────────────────────────────────────────────────────────────────
const tokens = (wei) => {
  const whole = wei / ETHER;
  const fraction = (wei % ETHER).toString().padStart(18, "0").replace(/0+$/, "");
  return whole.toLocaleString("en-US") + (fraction ? "." + fraction : "");
};
let failed = 0;
let passed = 0;
function section(title) {
  console.log(`\n${title}`);
}
function check(claim, ok, found) {
  if (ok) passed++;
  else failed++;
  console.log(`  ${ok ? "PASS" : "FAIL"}  ${claim}${found === undefined ? "" : `\n        found: ${found}`}`);
}
const same = (claim, found, expected, show = String) => check(claim, found === expected, found === expected ? undefined : `${show(found)} (expected ${show(expected)})`);
const note = (line) => console.log(`  NOTE  ${line}`);
let skipped = 0;
function skip(what) {
  skipped++;
  console.log(`  SKIP  ${what}: no endpoint would serve the transaction. Run this again with another endpoint.`);
}

// ── The checks ───────────────────────────────────────────────────────────────────────────────────────────
console.log(`CallZ on BNB Chain Testnet: checking the launch against ${RPC}`);

if (keccak(new Uint8Array()) !== "0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470") {
  throw new Error("this script's keccak-256 is broken; do not trust its results");
}

section("1. The network");
same("The endpoint is BNB Chain Testnet (chain id 97)", BigInt(await rpc("eth_chainId", [])), CHAIN_ID);

section("2. The contracts are the published code");
const here = path.dirname(fileURLToPath(import.meta.url));
const recordPath = path.join(here, "contracts", "deployment", "CallZLauncherFactory.create2.json");
if (fs.existsSync(recordPath)) {
  const record = JSON.parse(fs.readFileSync(recordPath, "utf8"));
  const preimage = "0xff" + record.deployer.slice(2) + record.salt.slice(2) + keccak(fromHex(record.initCode)).slice(2);
  const derived = addressOf(keccak(fromHex(preimage)));
  same("The factory's address follows from the recorded creation code (CREATE2: deployer, salt, code hash)", derived, FACTORY);
} else {
  note("contracts/deployment/CallZLauncherFactory.create2.json is not beside this script, so the CREATE2 check was skipped");
}
same("The factory's code on chain is the code recorded in the report", await codeHash(FACTORY), FACTORY_CODE_HASH);
same("The factory's beacon is the one in the report", await readAddress(FACTORY, "beacon()"), BEACON);
same("The beacon points at the CallZLauncher implementation in the report", await readAddress(FACTORY, "beaconImplementation()"), IMPLEMENTATION);
same("The implementation's code on chain is the compiled CallZLauncher.sol", await codeHash(IMPLEMENTATION), IMPLEMENTATION_CODE_HASH);
same("The factory uses Flap's Pool Launch Portal", await readAddress(FACTORY, "hub()"), PORTAL);
check("The factory has created at least one mint", (await readNumber(FACTORY, "launcherCount()")) >= 1n);
same("The first mint the factory created is the one in the report", await readAddress(FACTORY, "launchers(uint256)", [0n]), LAUNCHER);

section("3. The mint was set up as stated");
same("It was created by the stated wallet", await readAddress(LAUNCHER, "creator()"), CREATOR);
same("One flat price: 0.1 tBNB a pass", await readNumber(LAUNCHER, "nftPrice()"), PRICE, tokens);
same("A hard cap of 1.6 tBNB", await readNumber(LAUNCHER, "cap()"), CAP, tokens);
same("16 passes for sale, no more", await readNumber(LAUNCHER, "maxNFTs()"), PASSES);
const tokensPerPass = await readNumber(LAUNCHER, "tokensPerNFT()");
const holderPool = await readNumber(LAUNCHER, "holderPool()");
const poolToken = await readNumber(LAUNCHER, "poolToken()");
same("750,000,000 tokens (75%) set aside for the pool", poolToken, POOL_TOKENS, tokens);
same("250,000,000 tokens (25%) set aside for the passes", holderPool, HOLDER_TOKENS, tokens);
same("Every pass is worth the same: 15,625,000 tokens", tokensPerPass, TOKENS_PER_PASS, tokens);
check("The passes' shares add up to exactly what was set aside for them", tokensPerPass * PASSES === holderPool);
check("The pool's part and the passes' part add up to the whole supply", poolToken + holderPool === SUPPLY);

section("4. The mint filled and launched");
same("16 passes were minted", await readNumber(LAUNCHER, "minted()"), PASSES);
same("1.6 tBNB was raised: the cap, to the wei", await readNumber(LAUNCHER, "raised()"), CAP, tokens);
same("The mint is marked launched", await readBool(LAUNCHER, "launched()"), true);
same("Refunds are closed (there was nothing to refund)", await readBool(LAUNCHER, "refundsOpen()"), false);
same("No pass was burned", await readNumber(LAUNCHER, "burned()"), 0n);
same("The mint recorded the token it launched", await readAddress(LAUNCHER, "token()"), TOKEN);
same("The mint recorded the pool it funded", await readAddress(LAUNCHER, "pool()"), POOL);
same("The mint kept none of the raise", BigInt(await rpc("eth_getBalance", [LAUNCHER, "latest"])), 0n, tokens);

section("5. The launch transaction");
const TRANSFER = topicOf("Transfer(address,address,uint256)");
const launch = await receipt(LAUNCH_TX);
if (launch === undefined) skip("The launch transaction and everything it did");
else check("The launch transaction is on chain and succeeded", launch !== null && launch.status === "0x1");
if (launch) {
  same("It was a call to the mint", (launch.to ?? "nothing").toLowerCase(), LAUNCHER);
  same("It was sent by the stated wallet", launch.from.toLowerCase(), CREATOR);
  const logs = launch.logs.map((log) => ({ ...log, address: log.address.toLowerCase() }));
  const passMints = logs.filter((log) => log.address === LAUNCHER && log.topics[0] === TRANSFER && log.topics.length === 4 && addressOf(log.topics[1]) === ZERO);
  same("It minted the 16 passes, numbered 1 to 16", passMints.map((log) => BigInt(log.topics[3])).join(","), Array.from({ length: 16 }, (_, index) => index + 1).join(","));
  const sync = logs.filter((log) => log.address === POOL && log.topics[0] === topicOf("Sync(uint112,uint112)")).at(-1);
  check("The same transaction funded the pool", sync !== undefined);
  if (sync) {
    same("The pool received the whole raise: 1.6 tBNB (as WBNB)", BigInt("0x" + sync.data.slice(2, 66)), CAP, tokens);
    same("The pool received 750,000,000 tokens", BigInt("0x" + sync.data.slice(66, 130)), POOL_TOKENS, tokens);
  }
  const paidIn = logs.filter((log) => log.address === WBNB && log.topics[0] === TRANSFER && addressOf(log.topics[2]) === POOL);
  same("The BNB that went into the pool equals what the passes paid", paidIn.reduce((sum, log) => sum + BigInt(log.data), 0n), CAP, tokens);
  const lpMints = logs.filter((log) => log.address === POOL && log.topics[0] === TRANSFER && addressOf(log.topics[1]) === ZERO);
  check("LP tokens were created in the launch", lpMints.length > 0);
  check("Every LP token created in the launch went to a burn address, none to a person", lpMints.every((log) => [ZERO, DEAD].includes(addressOf(log.topics[2]))));
  same("The LP sent to the dead address is the amount in the report", lpMints.filter((log) => addressOf(log.topics[2]) === DEAD).reduce((sum, log) => sum + BigInt(log.data), 0n), LP_BURNED_AT_LAUNCH);
}
const creation = await receipt(CREATE_TX);
if (creation === undefined || launch === undefined) skip("The creation transaction coming before the launch");
else check("The creation transaction is on chain, succeeded, and came before the launch", creation !== null && creation.status === "0x1" && launch !== null && BigInt(creation.blockNumber) < BigInt(launch.blockNumber));

section("6. The token and its pool");
same("The token's symbol is CZTEST", await readString(TOKEN, "symbol()"), "CZTEST");
same("Its total supply is 1,000,000,000", await readNumber(TOKEN, "totalSupply()"), SUPPLY, tokens);
const pair = [await readAddress(POOL, "token0()"), await readAddress(POOL, "token1()")].sort().join(" + ");
same("The pool pairs the token with WBNB", pair, [WBNB, TOKEN].sort().join(" + "));
const burned = (await readNumber(POOL, "balanceOf(address)", [DEAD])) + (await readNumber(POOL, "balanceOf(address)", [ZERO]));
const lpSupply = await readNumber(POOL, "totalSupply()");
check("The LP burned at launch is still at the burn addresses (it cannot be moved)", burned >= LP_BURNED_AT_LAUNCH + 1000n);
if (burned === lpSupply) check("Right now, every LP token that exists is burned", true);
else note(`someone has added liquidity since the launch: ${lpSupply - burned} LP is held outside the burn addresses. That is theirs; the launch's own LP is still burned.`);

section("7. The claim");
const claim = await receipt(CLAIM_TX);
if (claim === undefined) skip("The claim transaction and what it paid");
else check("The claim transaction is on chain and succeeded", claim !== null && claim.status === "0x1");
if (claim) {
  const logs = claim.logs.map((log) => ({ ...log, address: log.address.toLowerCase() }));
  const claimed = logs.filter((log) => log.address === LAUNCHER && log.topics[0] === topicOf("Claimed(uint256,address,uint256)"));
  same("16 passes claimed in it", BigInt(claimed.length), PASSES);
  check("Each pass claimed exactly the same amount: 15,625,000 tokens", claimed.length > 0 && claimed.every((log) => BigInt(log.data) === TOKENS_PER_PASS));
  const paid = logs.filter((log) => log.address === TOKEN && log.topics[0] === TRANSFER && addressOf(log.topics[1]) === LAUNCHER);
  same("The mint paid out 250,000,000 tokens in total", paid.reduce((sum, log) => sum + BigInt(log.data), 0n), HOLDER_TOKENS, tokens);
  check("All of it went to the wallet that held the passes", paid.every((log) => addressOf(log.topics[2]) === CREATOR));
}
let allClaimed = true;
let stillHeld = 0;
for (let id = 1n; id <= PASSES; id++) {
  if (!(await readBool(LAUNCHER, "claimed(uint256)", [id]))) allClaimed = false;
  if ((await readAddress(LAUNCHER, "ownerOf(uint256)", [id])) === CREATOR) stillHeld++;
}
check("All 16 passes are marked claimed, so none can claim twice", allClaimed);
same("The mint holds no tokens any more: nothing was left behind", await readNumber(TOKEN, "balanceOf(address)", [LAUNCHER]), 0n, tokens);
same("Nothing more can be claimed by that wallet", await readNumber(LAUNCHER, "claimableOf(address)", [CREATOR]), 0n, tokens);
same("The passes were not burned by claiming: 16 still exist", await readNumber(LAUNCHER, "minted()") - (await readNumber(LAUNCHER, "burned()")), PASSES);
if (stillHeld === 16) check("The wallet that minted still holds all 16 passes", true);
else note(`${stillHeld} of the 16 passes are still in the minting wallet; the others have been transferred since.`);

console.log(`\n${passed} checks passed, ${failed} failed${skipped > 0 ? `, ${skipped} groups could not be read` : ""}.`);
if (failed > 0) {
  console.log("At least one fact on chain does not match the report.");
  process.exit(1);
}
if (skipped > 0) {
  console.log("Nothing that was read contradicts the report, but part of it could not be read. This is not a full check.");
  process.exit(2);
}
console.log("Every fact in the report that this script covers matches the chain.");
