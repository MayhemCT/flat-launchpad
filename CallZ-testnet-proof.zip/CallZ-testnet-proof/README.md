# CallZ testnet launch: proof package

CallZ ran its NFT pass mint, start to finish, on BNB Chain Testnet through Flap Pool Launch on 27 November 2026.
This package is the record of that launch and the means to check it against the public chain.

## What is here

| File | What it is |
| --- | --- |
| `CallZ-Testnet-Launch-Report.pdf` | The report: what was promised, what the chain shows, the transactions and addresses, and what this does and does not prove. Start here. |
| `check.mjs` | A script that reads the chain and compares 53 facts with the report. |
| `contracts/` | The two CallZ contracts that ran, Flap's base contracts they build on, the 17 tests, the deploy scripts and the deployment record. `contracts/REVIEW.md` is the note for a reviewer or auditor. |

## Check it yourself

You need [Node.js](https://nodejs.org) 18 or newer. Nothing else is installed, no wallet is used, and no
transaction is sent: the script only reads.

```
node check.mjs
```

It prints one line per fact, `PASS` or `FAIL`, and ends with a count. It exits with code 1 if anything fails.
By default it reads from the public endpoint `https://bsc-testnet-rpc.publicnode.com`. To read from an endpoint
you trust instead:

```
node check.mjs https://your-bnb-chain-testnet-endpoint
```

Run it from this folder: the check that ties the factory's address to its creation code reads
`contracts/deployment/CallZLauncherFactory.create2.json`.

## Without the script

Every transaction and address in the report links to the BNB Chain Testnet explorer. The mint's own page is
https://callz.fun/#/launcher/0x86a22874083777d066359d6ef3661c6d8f186e90.

## What this is not

It is proof that this launch did what CallZ says a launch does. It is not a security audit, and it is on
testnet. Section 5 of the report lists the limits in full.
