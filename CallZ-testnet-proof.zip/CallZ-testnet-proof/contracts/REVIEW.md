# CallZ on BNB Chain Testnet: contract package for review

The contracts CallZ runs on BNB Chain Testnet (chain id 97), where it launches tokens through Flap Pool Launch.
Source as of commit `18cd266` of https://github.com/MayhemCT/flat-launchpad (27 Nov 2026): the last commit that
changed either contract. Solidity 0.8.26, EVM version cancun, optimizer on with 99,999 runs (`foundry.toml`).

## What to review

Our own code is two files in `src/callz/`:

| File | What it is |
| --- | --- |
| `CallZLauncher.sol` | The NFT pass mint, built on Flap's `LauncherBase`. Passes are sold at one flat price up to a cap. The mint that reaches the cap launches the token through the Portal in the same transaction: the raise and the pool share of the supply go into the pool and the LP is burned. Each pass then claims an equal share of the rest. If the cap is missed, a pass is burned for its price. |
| `CallZLauncherFactory.sol` | A Flap Launcher Factory. The Portal calls it to create a `CallZLauncher`; each Launcher is an ERC-1967 beacon proxy. `upgradeVaultImplementation` is the only privileged function and only the Flap Guardian can call it. |

`src/flap/` holds Flap's own base contracts and interfaces that these two build on (from Flap's
FlapPoolLaunchVaultExample). They are Flap's code, included so the package compiles: only the ten files the two
contracts and their tests import.

## Deployed on BNB Chain Testnet

```
CallZLauncherFactory           0x873040D38Bd73eF1cE7d8D814278605CF6b697b3
UpgradeableBeacon (solady)     0x22E07928ABD89b20d560b6DFCb0E1E5D72c2Ab0a   created by the factory's constructor
CallZLauncher implementation   0xD9D4A8FC93156fed60DE5960A2A25b15591BF651   created by the factory's constructor

Flap Pool Launch Portal (hub)  0x000042108465206185A077Edc3F3fd2b49060000   Flap's contract
Flap Guardian                  0x00004d58290854c5E9880F4b5B1993c6Ad8b0000   Flap's address
```

An earlier factory, `0x2D085c23BBB95e8f0C34b046573BDc88fAd538F0`, holds the code from before `18cd266`. It is
unused and is not this package's code.

The factory was deployed with CREATE2 through the deterministic deployment proxy
(`0x4e59b44847b379578588920cA78FbF26c0B4956C`). `deployment/CallZLauncherFactory.create2.json` records the
deployer, the salt, the creation code and the resulting address.

### The deployed code is this package's code

Checked on 27 Nov 2026 against `https://bsc-testnet-rpc.publicnode.com`:

- Building this package with the libraries installed under `lib/` (see "Build and test") gives a
  `CallZLauncherFactory` creation code that is byte-for-byte the creation code in
  `deployment/CallZLauncherFactory.create2.json` (32,393 bytes).
- The factory's code on chain (6,877 bytes) equals the compiled runtime code once its one immutable, `beacon`,
  is set aside. On chain that immutable holds `0x22E07928ABD89b20d560b6DFCb0E1E5D72c2Ab0a`, the address
  `beacon()` returns.
- The implementation's code on chain (24,156 bytes) equals the compiled `CallZLauncher` runtime code exactly. It
  has no immutables.

The metadata hash at the end of the bytecode depends on the source paths and remappings, so the comparison only
holds with the layout in this package: `src/`, `lib/` and the `remappings.txt` given.

Whether the sources are verified on the testnet explorer (testnet.bscscan.com) was not checked for this
package; the comparison above was made directly against the chain.

## A live launch to review against

One mint has been created, filled and launched on BNB Chain Testnet from the site's own launch page
(https://callz.fun/#/launch/testnet), on 27 Nov 2026:

```
Launcher and pass NFT (CZTEST-PASS)   0x86A22874083777D066359D6ef3661C6D8f186E90
  16 passes at 0.1 tBNB, cap 1.6 tBNB, 75% of the supply to the pool, buy tax 3%, sell tax 5%
Token it launched (CZTEST)            0xF53F1C30ac65095f04845F10E1E1935702387777
Pool                                  0xB9E05D4a0B7DC8fB98BdCC12CeD52D107Ef6Ac2d

Created                0x598a2d9549deb0ae6ff3ef2212df7fe7958199c1eccb51419d40086ccd20204a
Minted to the cap and launched, in one transaction
                       0xf61c38701bd424d60b316d0578b3fd2f778372385b9e95b6a5c529fd29fc26fa
```

State read from the chain after the launch:

- `minted` 16, `raised` 1.6 tBNB, `launched` true, `refundsOpen` false. One wallet holds all 16 passes.
- Token supply 1,000,000,000. The pool holds 1.6 WBNB and 750,000,000 CZTEST.
- LP supply 34,641,016,151,377,545,870,548: 34,641,016,151,377,545,869,548 at
  `0x000000000000000000000000000000000000dEaD` and the minimum-liquidity 1,000 at the zero address. No LP is
  held by anyone else.
- The 16 passes claimed in one transaction,
  `0x981e085b8addf6f9bf2b381e9f112bec5772c3b148bcfc7ebc739683b212ec8e`: 16 `Claimed` events of 15,625,000
  CZTEST each, 250,000,000 in total. Afterwards every pass is marked `claimed`, the Launcher holds 0 CZTEST and
  0 tBNB, `claimableOf` for the holder returns 0, and the holder still owns all 16 passes.

The site's page for this mint is https://callz.fun/#/launcher/0x86a22874083777d066359d6ef3661c6d8f186e90.

The refund path (a cap that is missed, then `refund()`) has not been run on the live testnet. It is covered by
`test_09_burnToRefundWhenTheCapIsMissed` and `test_10_guardianCanOpenRefundsEarly`.

## Known and open

- **Liquidity floor.** `initialize()` reads the Portal's floor for the chosen pool share (`graduationFloorV2`
  for the creation floor in USD, `launcherFactoryMultiplier` for this factory's multiplier, `launchQuoteConfig`
  for the Portal's BNB price) and reverts with `CapBelowLaunchFloor(cap, floor)` when the cap is under it. The
  check is made at the price and multiplier of the moment of creation; both can move before the launch. If
  they move enough, the launch is rejected by the Portal, the cap cannot be reached, and passes are refunded
  after the deadline.
- **Rounding dust.** `tokensPerNFT` is computed first, `holderPool = tokensPerNFT * maxNFTs`, and what the
  division leaves over is added to `poolToken`. The Launcher holds nothing after the last claim.
- **Scam-word check at creation: not done.** `isScamWord(string)` reverts on the Pool Launch Portal and on the
  other Flap contracts we tried, on BNB Chain and BNB Chain Testnet. With the contract and exact signature we
  will call it in `initialize()`.
- **Upgrades.** Every Launcher of this factory points at one beacon. The Flap Guardian can replace the
  implementation for all of them through `upgradeVaultImplementation`. `test_15` checks that an upgrade keeps
  every Launcher's state.
- **Mainnet.** On BNB Chain, Pool Launch is permissioned: `Portal.newLauncher` reverts for a factory Flap has
  not audited and enabled. This factory is not enabled there.
- The contracts have not been audited.

## Dependencies (not in this package)

- Solady 0.1.26: `ERC721`, `Base64`, `LibString`, `SafeTransferLib`, `LibClone`, `UpgradeableBeacon`
- OpenZeppelin Contracts Upgradeable 4.9.6: `Initializable` (and `ClonesUpgradeable`, scripts and tests only)
- OpenZeppelin Contracts 4.9.6: `IERC20` (tests only)
- forge-std 1.8.2 (scripts and tests only)

## Build and test

```
forge install vectorized/solady@v0.1.26 OpenZeppelin/openzeppelin-contracts@v4.9.6 OpenZeppelin/openzeppelin-contracts-upgradeable@v4.9.6 foundry-rs/forge-std@v1.8.2
forge build
BSC_TESTNET_RPC_URL=<a BNB Chain Testnet endpoint> forge test --isolate --match-path test/callz/CallZLauncher.BSCTest.fork.t.sol
```

`forge install` needs a git repository: run `git init` in the package folder first.

The tests are fork tests against the live Pool Launch Portal, so they need an RPC endpoint.
`CallZLauncher.BSCTest.fork.t.sol` runs the suite in `CallZLauncher.fork.t.sol` on BNB Chain Testnet; it was run
on 27 Nov 2026 against `https://bsc-testnet-rpc.publicnode.com`: 17 of 17 pass.
`CallZLauncher.BSC.fork.t.sol` runs the same suite on a fork of BNB Chain and needs `BSC_RPC_URL`; it was not
re-run for this package.

## Scripts

- `script/Deploy.s.sol` deploys `CallZLauncherFactory`.
- `script/CreateLauncher.s.sol` creates one Launcher through the Portal, the same call the launch page makes.

Neither reads a private key from a file or the environment: both are sent with a Foundry keystore account
(`--account`). `.env.example` lists the two RPC variables.
