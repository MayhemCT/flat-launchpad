// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {Script, console} from "forge-std/Script.sol";
import {ClonesUpgradeable} from "@openzeppelin-contracts-upgradeable/proxy/ClonesUpgradeable.sol";

import {IPortal} from "src/flap/IPortal.sol";
import {LaunchVaultAddresses} from "src/flap/LaunchVaultAddresses.sol";
import {CallZLauncherFactory} from "src/callz/CallZLauncherFactory.sol";
import {CallZLauncher, CallZConfig} from "src/callz/CallZLauncher.sol";

/// @notice Creates one CallZ Launcher through the Portal, the same call a launch page makes.
///
///   Environment:
///     FACTORY        CallZLauncherFactory address
///     TOKEN_NAME     token name
///     TOKEN_SYMBOL   token symbol
///     TOKEN_META     metadata CID (may be empty)
///     NFT_PRICE      wei per NFT
///     CAP            wei to raise: at most 10 BNB and an exact multiple of NFT_PRICE
///     SALE_DURATION  mint window in seconds
///     POOL_SHARE_BPS share of supply in the pool, bps (default 5000)
///     BUY_TAX_BPS    buy tax, bps (default 300)
///     SELL_TAX_BPS   sell tax, bps (default 500)
///
///   forge script script/CreateLauncher.s.sol --rpc-url $BSC_TESTNET_RPC_URL --account <keystore-name> --broadcast
contract CreateLauncher is Script {
    /// @dev The FlapDirectTaxToken implementation the Portal clones (same address on both chains).
    address internal constant TOKEN_IMPL = 0x7777c57ff7dc441c1715b2e36fa581c48B782222;

    function run() external returns (address launcher) {
        CallZLauncherFactory factory = CallZLauncherFactory(vm.envAddress("FACTORY"));
        IPortal portal = IPortal(LaunchVaultAddresses.hub());

        CallZConfig memory c;
        c.name = vm.envString("TOKEN_NAME");
        c.symbol = vm.envString("TOKEN_SYMBOL");
        c.meta = vm.envOr("TOKEN_META", string(""));
        c.nftPrice = vm.envUint("NFT_PRICE");
        c.cap = vm.envUint("CAP");
        c.saleDuration = vm.envUint("SALE_DURATION");
        c.poolShareBps = uint16(vm.envOr("POOL_SHARE_BPS", uint256(5000)));
        c.buyTaxBps = uint16(vm.envOr("BUY_TAX_BPS", uint256(300)));
        c.sellTaxBps = uint16(vm.envOr("SELL_TAX_BPS", uint256(500)));
        c.salt = _mineSalt(address(portal), keccak256(abi.encode(address(factory), c.name, c.symbol, block.number)));

        uint256 fee = portal.SALT_LOCK_FEE();
        vm.startBroadcast();
        launcher = portal.newLauncher{value: fee}(address(factory), abi.encode(c));
        vm.stopBroadcast();

        console.log("launcher     ", launcher);
        console.log("token (soon) ", ClonesUpgradeable.predictDeterministicAddress(TOKEN_IMPL, c.salt, address(portal)));
        console.log("target raise ", CallZLauncher(launcher).targetRaise());
        console.log("sale deadline", CallZLauncher(launcher).saleDeadline());
    }

    /// @dev The Portal only locks a salt whose token address ends in 0x7777: about 65,000 tries.
    function _mineSalt(address portal, bytes32 seed) internal pure returns (bytes32 salt) {
        for (uint256 i;; ++i) {
            salt = keccak256(abi.encode(seed, i));
            if (uint16(uint160(ClonesUpgradeable.predictDeterministicAddress(TOKEN_IMPL, salt, portal))) == 0x7777) {
                return salt;
            }
        }
    }
}
